import pygame

pygame.mixer.init()

som_passos = pygame.mixer.Sound("assets/sdf/audio de passos .mp3")
som_recarregando_pistola = pygame.mixer.Sound("assets/sdf/Recarregando Pistola.mp3")
som_de_pistola = pygame.mixer.Sound("assets/sdf/Som De Pistola.mp3")
som_de_selecionar_power_up = pygame.mixer.Sound("assets/sdf/som de selecionar power up.mp3")
som_de_subir_de_nivel = pygame.mixer.Sound("assets/sdf/som de subir de nivel.mp3")
som_ganho_de_xp = pygame.mixer.Sound("assets/sdf/Som Ganho De XP.mp3")

canal_passos = som_passos.play(maxtime=1000)
canal_recarregando_pistola = som_recarregando_pistola.play()
canal_de_pistola = som_de_pistola.play()
canal_de_selecionar_power_up = som_de_selecionar_power_up.play()
canal_de_subir_de_nivel = som_de_subir_de_nivel.play()
canal_ganho_de_xp = som_ganho_de_xp.play()